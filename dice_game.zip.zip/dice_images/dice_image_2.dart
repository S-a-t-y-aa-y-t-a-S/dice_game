import 'package:auxilliary/dice_images/decoration.dart';
import 'package:flutter/material.dart';

class DiceImage2 extends StatelessWidget {
  const DiceImage2({super.key});
  @override
  Widget build(context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              CircleDecoration(
                widthLength: 30,
                heightLength: 30,
              ),
            ],
          ),
          Expanded(
              child:
                  Container()), // will take up space at the middle of the dice
          const Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CircleDecoration(
                widthLength: 30,
                heightLength: 30,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
