import 'package:flutter/material.dart';

class CircleDecoration extends StatelessWidget {
  const CircleDecoration(
      {required this.heightLength, required this.widthLength, super.key});
  final double heightLength;
  final double widthLength;
  @override
  Widget build(context) {
    return Container(
      height: heightLength,
      width: widthLength,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(180),
      ),
    );
  }
}
