import 'package:flutter/material.dart';

class Footer extends StatelessWidget {
  Footer(this.length, {super.key});
  int length;
  @override
  Widget build(context) => Container(
        decoration:
            const BoxDecoration(shape: BoxShape.rectangle, color: Colors.teal),
        padding:
            const EdgeInsets.only(top: 20, bottom: 20, right: 40, left: 40),
        child: Center(
          child: Text(
            "You rolled the dice $length number of times",
            style: const TextStyle(fontSize: 18),
          ),
        ),
      );
}
