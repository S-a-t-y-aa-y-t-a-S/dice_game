import 'package:auxilliary/dice_images/decoration.dart';
import 'package:flutter/material.dart';

class DiceImage6 extends StatelessWidget {
  const DiceImage6({super.key});
  @override
  Widget build(context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CircleDecoration(heightLength: 30, widthLength: 30),
              Padding(padding: EdgeInsets.only(left: 110)),
              CircleDecoration(heightLength: 30, widthLength: 30),
            ],
          ),
          Expanded(child: Container()),
          const Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CircleDecoration(heightLength: 30, widthLength: 30),
              Padding(padding: EdgeInsets.only(left: 110)),
              CircleDecoration(heightLength: 30, widthLength: 30),
            ],
          ),
          Expanded(child: Container()),
          const Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CircleDecoration(heightLength: 30, widthLength: 30),
              Padding(padding: EdgeInsets.only(left: 110)),
              CircleDecoration(heightLength: 30, widthLength: 30),
            ],
          ),
        ],
      ),
    );
  }
}
