import 'package:flutter/material.dart';
import 'package:auxilliary/dice_images/decoration.dart';

class DiceImage5 extends StatelessWidget {
  const DiceImage5({super.key});
  @override
  Widget build(context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CircleDecoration(heightLength: 30, widthLength: 30),
              Padding(padding: EdgeInsets.only(left: 110)),
              CircleDecoration(heightLength: 30, widthLength: 30),
            ],
          ),
          Expanded(child: Container()),
          const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleDecoration(heightLength: 30, widthLength: 30),
            ],
          ),
          Expanded(child: Container()),
          const Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CircleDecoration(heightLength: 30, widthLength: 30),
              Padding(padding: EdgeInsets.only(left: 110)),
              CircleDecoration(heightLength: 30, widthLength: 30),
            ],
          ),
        ],
      ),
    );
  }
}
