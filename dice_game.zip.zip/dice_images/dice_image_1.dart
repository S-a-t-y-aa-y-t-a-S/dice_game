import 'package:auxilliary/dice_images/decoration.dart';
import 'package:flutter/material.dart';

class DiceImage1 extends StatelessWidget {
  const DiceImage1({super.key});
  @override
  Widget build(context) {
    return const Padding(
        padding: EdgeInsets.all(80),
        child: CircleDecoration(
          heightLength: 100,
          widthLength: 100,
        ));
  }
}
