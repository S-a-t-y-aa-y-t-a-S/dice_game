import 'package:auxilliary/record/filter_not_empty.dart';
import 'package:auxilliary/record/is_empty.dart';
import 'package:auxilliary/record/is_not_empty.dart';
import 'package:auxilliary/record/sorted_not_empty.dart';
import 'package:flutter/material.dart';

class SummaryRecord extends StatefulWidget {
  SummaryRecord({required this.statistics, super.key});
  List<Map<String, int>> statistics;
  @override
  State<SummaryRecord> createState() => _SummaryRecord();
}

enum Choice { sort, filter }

class _SummaryRecord extends State<SummaryRecord> {
  String reference = '';
  Widget? nextState;
  Choice? selectedChoice;
  int number = 0;
  List<Map<String, int>> listItems = [];

  void changeState1(int selectedNumber1) {
    listItems = widget.statistics;
    listItems = widget.statistics
        .where((element) => element['face']! < selectedNumber1)
        .toList();
    setState(() {
      reference = 'filter';
    });
  }

  void changeState2(int selectedNumber2) {
    listItems = widget.statistics;
    if (selectedNumber2 == 1) {
      listItems.sort((a, b) => a['face']!.compareTo(b['face'] as num));
    } else if (selectedNumber2 == 2) {
      listItems.sort((b, a) => a['face']!.compareTo(b['face'] as num));
    }
    setState(() {
      reference = 'sort';
    });
  }

  @override
  Widget build(context) {
    if (widget.statistics.isEmpty) {
      nextState = const IsEmpty();
    } else if (reference == 'summary') {
      List<Map<String, int>> listItems = widget.statistics;
      listItems.sort((a, b) => a['counter']!.compareTo(b['counter'] as num));
      nextState = IsNotEmpty(listItems);
    } else if (reference == 'sort') {
      nextState = IsNotEmpty(listItems);
    } else if (reference == 'filter') {
      nextState = IsNotEmpty(listItems);
    } else {
      nextState = IsNotEmpty(widget.statistics);
    }
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back_ios_new_rounded),
            color: Colors.black,
          ),
          backgroundColor: Colors.amber,
          actions: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 200),
              child: TextButton(
                onPressed: () {
                  setState(() {
                    reference = 'summary';
                  });
                },
                child: const Text(
                  "Summary",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
            ),
            PopupMenuButton(
                icon: const Icon(
                  Icons.more_vert_outlined,
                  color: Colors.black,
                ),
                color: Colors.white,
                initialValue: selectedChoice,
                onSelected: (Choice selectedItem) {
                  setState(() {
                    selectedChoice = selectedItem;
                  });
                },
                itemBuilder: (ctx) => <PopupMenuEntry<Choice>>[
                      PopupMenuItem(
                          value: Choice.sort,
                          child: TextButton.icon(
                              onPressed: () {
                                showModalBottomSheet(
                                  context: context,
                                  builder: (context) => SortNotEmpty(
                                    changeState: changeState2,
                                    selectedNumber: number,
                                  ),
                                );
                                Navigator.pop(ctx);
                              },
                              icon: const Icon(Icons.sort),
                              label: const Text(
                                "Sort",
                                style: TextStyle(color: Colors.black),
                              ))),
                      PopupMenuItem(
                          value: Choice.filter,
                          child: TextButton.icon(
                              onPressed: () {
                                showModalBottomSheet(
                                  context: context,
                                  builder: (context) => FilterNotEmpty(
                                    changeState: changeState1,
                                    selectedNumber: number,
                                  ),
                                );
                                Navigator.pop(ctx);
                              },
                              icon: const Icon(Icons.filter_alt_outlined),
                              label: const Text(
                                "Filter",
                                style: TextStyle(color: Colors.black),
                              ))),
                    ]),
          ],
        ),
        body: nextState,
      ),
    );
  }
}
