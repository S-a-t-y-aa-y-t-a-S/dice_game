import 'package:flutter/material.dart';
import 'package:auxilliary/dice_images/footer.dart';

class IsNotEmpty extends StatelessWidget {
  IsNotEmpty(this.stats, {super.key});
  List<Map<String, int>> stats;
  @override
  Widget build(context) {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(8.0),
            itemBuilder: (context, index) {
              return Card(
                child: Container(
                  height: 80,
                  color: const Color.fromARGB(255, 110, 209, 173),
                  child: Center(
                    child: Text(
                      'Dice roll- ${stats[index]['counter']}\nOutcome- ${stats[index]['face']}',
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
              );
            },
            itemCount: stats.length,
          ),
        ),
        Footer(stats.length),
      ],
    );
  }
}
