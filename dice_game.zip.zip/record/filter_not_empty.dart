import 'package:flutter/material.dart';

class FilterNotEmpty extends StatefulWidget {
  FilterNotEmpty(
      {super.key, required this.changeState, required this.selectedNumber});
  void Function(int selectedNumber) changeState;
  int selectedNumber;
  @override
  State<FilterNotEmpty> createState() => _FilterNotEmpty();
}

class _FilterNotEmpty extends State<FilterNotEmpty> {
  List<Map> checkListItems = [
    {
      'title': 'Outcome below 6',
      'number': 6,
      'value': false,
    },
    {
      'title': 'Outcome below 4',
      'number': 4,
      'value': false,
    },
    {
      'title': 'Outcome below 2',
      'number': 2,
      'value': false,
    },
  ];
  @override
  Widget build(context) {
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: List.generate(
              checkListItems.length,
              (index) => CheckboxListTile(
                contentPadding: const EdgeInsets.symmetric(vertical: 5),
                controlAffinity: ListTileControlAffinity.leading, // optional
                value: checkListItems[index]['value'], // unchecked box
                onChanged: (value) {
                  setState(() {
                    for (var element in checkListItems) {
                      element['value'] = false;
                    }
                    checkListItems[index]['value'] = value;
                    widget.selectedNumber = checkListItems[index]['number'];
                  });
                },
                title: Text(checkListItems[index]['title']),
                dense: false,
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 10, right: 15),
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor:
                            const Color.fromARGB(255, 240, 203, 222)),
                    onPressed: () {
                      widget.changeState(widget.selectedNumber);
                      Navigator.pop(context);
                    },
                    child: const Text(
                      "Apply",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 81, 21, 92)),
                    )),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
