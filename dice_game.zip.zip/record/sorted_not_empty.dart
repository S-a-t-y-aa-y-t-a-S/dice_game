import 'package:flutter/material.dart';

class SortNotEmpty extends StatefulWidget {
  SortNotEmpty(
      {super.key, required this.changeState, required this.selectedNumber});
  void Function(int selectedNumber) changeState;
  int selectedNumber;
  @override
  State<SortNotEmpty> createState() => _FilterNotEmpty();
}

class _FilterNotEmpty extends State<SortNotEmpty> {
  List<Map> checkListItems = [
    {
      'title': 'Ascending Order',
      'number': 1,
      'value': false,
    },
    {
      'title': 'Descending Order',
      'number': 2,
      'value': false,
    },
  ];
  @override
  Widget build(context) {
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: List.generate(
              checkListItems.length,
              (index) => CheckboxListTile(
                contentPadding: const EdgeInsets.symmetric(vertical: 5),
                controlAffinity: ListTileControlAffinity.leading, // optional
                value: checkListItems[index]['value'], // unchecked box
                onChanged: (value) {
                  setState(() {
                    for (var element in checkListItems) {
                      element['value'] = false;
                    }
                    checkListItems[index]['value'] = value;
                    widget.selectedNumber = checkListItems[index]['number'];
                  });
                },
                title: Text(checkListItems[index]['title']),
                dense: false,
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 10, right: 15),
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor:
                            const Color.fromARGB(255, 240, 203, 222)),
                    onPressed: () {
                      widget.changeState(widget.selectedNumber);
                      Navigator.pop(context);
                    },
                    child: const Text(
                      "Apply",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 81, 21, 92)),
                    )),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
