import 'package:flutter/material.dart';

class IsEmpty extends StatelessWidget {
  const IsEmpty({super.key});
  @override
  Widget build(context) {
    return Center(
      child: Container(
        height: 90,
        width: 300,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20.0),
            shape: BoxShape.rectangle,
            color: const Color.fromARGB(255, 23, 143, 152)),
        child: const Padding(
          padding: EdgeInsets.all(8.0),
          child: Text(
            "You have not rolled the dice yet!! Play the game and have fun..",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
