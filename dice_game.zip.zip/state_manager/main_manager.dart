import 'dart:math';
import 'package:auxilliary/state_manager/manager_2.dart';
import 'package:flutter/material.dart';
import 'package:auxilliary/state_manager/manager_1.dart';
import 'package:auxilliary/state_manager/manager_3.dart';
import 'package:auxilliary/dice_images/dice_image_1.dart';
import 'package:auxilliary/dice_images/dice_image_2.dart';
import 'package:auxilliary/dice_images/dice_image_3.dart';
import 'package:auxilliary/dice_images/dice_image_4.dart';
import 'package:auxilliary/dice_images/dice_image_5.dart';
import 'package:auxilliary/dice_images/dice_image_6.dart';

class Manager extends StatefulWidget {
  const Manager({super.key});
  @override
  State<Manager> createState() => _ManagerState();
}

final randomize = Random();

class _ManagerState extends State<Manager> {
  Widget? changeState = const DiceImage1();
  var face = 1, temp = 1, counter = 0;
  List<Map<String, int>> statistics = [];
  void diceRoll() async {
    counter++;
    while (face == temp) {
      face = randomize.nextInt(6) + 1;
    }
    statistics.add({'counter': counter, 'face': face});
    setState(() {
      if (face == 1) {
        changeState = const DiceImage1();
      } else if (face == 2) {
        changeState = const DiceImage2();
      } else if (face == 3) {
        changeState = const DiceImage3();
      } else if (face == 4) {
        changeState = const DiceImage4();
      } else if (face == 5) {
        changeState = const DiceImage5();
      } else if (face == 6) {
        changeState = const DiceImage6();
      }
    });
    temp = face;
  }

  @override
  Widget build(context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(245, 255, 255, 255),
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: const Text(
          "Let's play",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Manager1(
              changeState: changeState,
            ),
            const SizedBox(
              height: 30,
            ),
            Manager2(diceRoll: diceRoll),
            const SizedBox(
              height: 30,
            ),
            Manager3(statistics: statistics),
          ],
        ),
      ),
    );
  }
}
