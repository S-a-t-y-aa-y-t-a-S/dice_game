import 'package:flutter/material.dart';
import 'package:auxilliary/dice_images/dice_image_1.dart';

class Manager1 extends StatelessWidget {
  Manager1({required this.changeState, super.key});
  Widget? changeState = const DiceImage1();
  @override
  Widget build(context) {
    return Container(
      width: 200,
      height: 200,
      decoration: BoxDecoration(
          //color: Color.fromARGB(255, 230, 240, 239),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            width: 5,
            color: Colors.teal,
          )),
      child: changeState,
    );
  }
}
