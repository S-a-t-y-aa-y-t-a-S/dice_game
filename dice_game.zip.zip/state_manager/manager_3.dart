import 'package:flutter/material.dart';
import 'package:auxilliary/record/summary_record.dart';

class Manager3 extends StatelessWidget {
  const Manager3({required this.statistics, super.key});
  final List<Map<String, int>> statistics;
  @override
  Widget build(context) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 15,
        right: 15,
        top: 15,
      ),
      child: Align(
        alignment: Alignment.bottomCenter,
        child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.brown),
            icon: const Icon(
              Icons.add_chart_sharp,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                    builder: (context) =>
                        SummaryRecord(statistics: statistics)),
              );
            },
            label: const Text(
              "Your stats",
              style: TextStyle(color: Colors.white),
            )),
      ),
    );
  }
}
