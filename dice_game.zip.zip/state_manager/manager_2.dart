import 'package:flutter/material.dart';

class Manager2 extends StatelessWidget {
  const Manager2({required this.diceRoll, super.key});
  final void Function() diceRoll;
  @override
  Widget build(context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
          backgroundColor: const Color.fromARGB(255, 255, 184, 53)),
      onPressed: diceRoll,
      child: const Text("Roll the dice",
          style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20)),
    );
  }
}
